
INSERT INTO student VALUES('geetika',35242363,'noida',4);

INSERT INTO student VALUES('praveen',5326537,'dwarka',5);

INSERT INTO student VALUES('rahul',5326537,'dwarka',7);

INSERT INTO subject VALUES('C',null);

INSERT INTO subject VALUES('C++',null);

INSERT INTO subject VALUES('Play',null);

INSERT INTO student_subject VALUES(4, 2);

INSERT INTO student_subject VALUES(5, 1);



