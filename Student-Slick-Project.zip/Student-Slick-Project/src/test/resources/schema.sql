
CREATE TABLE student (name varchar(200),phone Int,address varchar(200),id int PRIMARY KEY auto_increment);

CREATE TABLE subject(name varchar(200),id int PRIMARY KEY auto_increment );

CREATE TABLE student_subject(studid int NOT NULL,subid int NOT NULL,PRIMARY KEY(studid,subid), FOREIGN KEY (studid) references student(id),FOREIGN KEY (subid) references subject(id));

