package Repository

import connection.H2DBComponent
import org.scalatest.FunSuite
import scala.concurrent.duration._
import scala.concurrent.Await

/**
  * Created by knodus on 7/3/16.
  */
class SubjectDataTest extends FunSuite with SubjectRepo with H2DBComponent{

  test("Add new Subject") {
    val response = createSubject(Subject("Play",2))
    val actualResult=Await.result(response,2 seconds)
    assert(actualResult===1)
  }

  test("Update Subject") {
    val response = updateByName("Play",Subject("Play1",6))
    val actualResult=Await.result(response,2 seconds)
    assert(actualResult===1)
  }

  test("Delete Subject") {
    val response = deleteByName("Play")
    val actualResult=Await.result(response,2 seconds)
    assert(actualResult===1)
  }

  test("Get All Subject"){
    val response = getAllSubject()
    val actualResult=Await.result(response,2 seconds)
    val expectedResult=List(Subject("C",1), Subject("C++",2), Subject("Play",3))
    assert(actualResult===expectedResult)
  }
}
