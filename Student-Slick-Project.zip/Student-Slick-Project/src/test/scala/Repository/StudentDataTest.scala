package Repository

import connection.H2DBComponent
import org.scalatest.FunSuite
import org.scalatest.concurrent.ScalaFutures
import scala.concurrent.duration._

import scala.concurrent.Await

/**
  * Created by knodus on 7/3/16.
  */
class StudentDataTest extends FunSuite with StudentRepo with H2DBComponent {

  test("Add new Student") {
    val response = createStudent(Student("Antra",4325346,"Dabhri",8))
    val actualResult=Await.result(response,2 seconds)
    assert(actualResult===1)
  }

  test("Delete Student") {
    val response = deleteById(7)
    val actualResult=Await.result(response,2 seconds)
    assert(actualResult===1)
  }

  test("Update Student") {
    val response = updateByName("rahul",Student("kanu",3254362,"dholakua",6))
    val actualResult=Await.result(response,2 seconds)
    assert(actualResult===1)
  }

  test("Get All"){
    val response = getAllStudent()
    val actualResult=Await.result(response,2 seconds)
    val expectedResult=List(Student("geetika",35242363,"noida",4), Student("praveen",5326537,"dwarka",5), Student("rahul",5326537,"dwarka",7))
    assert(actualResult===expectedResult)
  }
}
