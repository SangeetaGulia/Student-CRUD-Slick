package Repository

import connection.H2DBComponent
import org.scalatest.FunSuite
import scala.concurrent.duration._
import scala.concurrent.Await

/**
  * Created by knodus on 7/3/16.
  */
class StudentSubjectTest extends FunSuite with StudSubRepository with H2DBComponent {

  test("Add new Student-Subject") {
    val response = create(StudentSubjectData(5,2))
    val actualResult=Await.result(response,2 seconds)
    assert(actualResult===1)
  }

  test("Get Student by SubjectId"){
    val response = searchByStudent(4)
    val actualResult=Await.result(response,2 seconds)
    assert(actualResult.toList===List(("geetika","C++")))
  }

  test("Get Subject by StudentId"){
    val response = searchBySubject(2)
    val actualResult=Await.result(response,2 seconds)
    assert(actualResult.toList===List(("C++","geetika")))
  }

  test("Get All StudentSubject Mapping"){
    val response = getAllStudentSubject()
    val actualResult=Await.result(response,2 seconds)
    val expectedResult=List(StudentSubjectData(4,2), StudentSubjectData(5,1))
    assert(actualResult===expectedResult)
  }


}
