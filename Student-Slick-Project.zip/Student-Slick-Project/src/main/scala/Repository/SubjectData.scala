package Repository

import connection.DbComponent
import slick.driver.PostgresDriver.api._

import scala.concurrent.Future

/**
  * Created by knodus on 7/3/16.
  */


case class Subject(name:String,id:Int=0)

trait SubTable { this: DbComponent =>

  class SubjectTable(tag: Tag) extends Table[Subject](tag, "subject") {
    val name = column[String]("name", O.SqlType("VARCHAR(200)"))
    val id = column[Int]("id", O.PrimaryKey, O.AutoInc)
    def * = (name, id) <>(Subject.tupled, Subject.unapply)
  }

  val subTableQuery = TableQuery[SubjectTable]

}

trait SubjectRepo extends SubTable{ this: DbComponent =>

  def createSubject(subject: Subject): Future[Int]= {
    // val createStatement = studTableQuery.schema.create
    // val db = Database.forConfig("mydb")
    val insert = subTableQuery += subject
    db.run { insert }

  }


  def updateByName(name:String,subject:Subject):Future[Int] ={

    val updateStatement = subTableQuery.filter(_.name ===name).update(subject)
    //val futureResult = db.run{ createStatement  }
    db.run { updateStatement }
  }

  def deleteByName(name:String):Future[Int]={

    val deleteStatement = subTableQuery.filter(_.name ===name).delete
      //val futureResult = db.run{ createStatement  }
    db.run { deleteStatement }

  }

  def getAllSubject():Future[List[Subject]]= {
    db.run {  subTableQuery.to[List].result
    }

  }

}




