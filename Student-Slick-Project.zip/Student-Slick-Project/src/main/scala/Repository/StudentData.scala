package Repository

import connection.DbComponent
import slick.driver.PostgresDriver.api._
import scala.concurrent.Future
import com.typesafe.config.ConfigFactory

/**
  * Created by knodus on 7/3/16.
  */

case class Student(name:String,phone:Int,address:String,id:Int=0)

trait StudTable  { this: DbComponent =>

  class StudentTable(tag: Tag) extends Table[Student](tag, "student") {
    val name = column[String]("name", O.SqlType("VARCHAR(200)"))
    val phone = column[Int]("phone", O.SqlType("Int"))
    val address = column[String]("address", O.SqlType("VARCHAR(200)"))
    val id = column[Int]("id", O.PrimaryKey, O.AutoInc)
    def * = (name, phone, address, id) <>(Student.tupled, Student.unapply)
  }

  val studTableQuery = TableQuery[StudentTable]

}

trait StudentRepo extends StudTable{ this: DbComponent =>

  def createStudent(student: Student):Future[Int]= {

    val insertStatement = studTableQuery += student
    db.run { insertStatement }

  }

  def deleteById(id:Int): Future[Int] ={

    val deleteStatement = studTableQuery.filter(_.id ===id).delete
    //val futureResult = db.run{ createStatement  }
    db.run { deleteStatement }

  }

  def updateByName(name:String,student:Student): Future[Int] ={

    val updateStatement = studTableQuery.filter(_.name ===name).update(student)
    //val futureResult = db.run{ createStatement  }
    db.run { updateStatement }
  }

  def getAllStudent():Future[List[Student]]={
    db.run {
      studTableQuery.to[List].result
    }
  }



}

