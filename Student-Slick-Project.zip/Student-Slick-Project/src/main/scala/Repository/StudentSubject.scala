package Repository

/**
  * Created by knodus on 7/3/16.
  */

import connection.DbComponent
import slick.driver.PostgresDriver.api._

import scala.concurrent.Future


case class StudentSubjectData(studId:Int,SubId:Int)

trait StudSubTable extends StudTable with SubTable{ this: DbComponent =>
    class StudentSubject(tag: Tag) extends Table[StudentSubjectData](tag, "student_subject") {

        val studid = column[Int]("studid")
        val subid = column[Int]("subid")
        def pk = primaryKey("pkstudentssubjects", (studid,subid))
        def studentid = foreignKey("stud_fk", studid, studTableQuery)(_.id)
        def subjectid = foreignKey("sub_fk", subid, subTableQuery)(_.id)

        def * = (studid, subid) <>(StudentSubjectData.tupled, StudentSubjectData.unapply)
    }

    val studsubTableQuery = TableQuery[StudentSubject]

}

trait StudSubRepository extends StudSubTable {
  this: DbComponent =>

  def create(studentSubject: StudentSubjectData): Future[Int] = {
    val insert = studsubTableQuery += studentSubject
    db.run {
      insert
    }
    //val db = Database.forConfig("mydb")
  }

  def searchByStudent(studentId: Int): Future[Seq[(String, String)]] = {
    val retrieveSubjects = for {
      ((sub, studsub), stu) <- studTableQuery.filter(_.id === studentId).join(studsubTableQuery).on(_.id === _.studid).
        join(subTableQuery).on(_._2.subid === _.id)
    } yield (sub.name, stu.name)

    db.run { retrieveSubjects.result }
  }

  def searchBySubject(subjectId:Int) : Future[Seq[(String,String)]]={
    val retrieveStudents = for {
      ((sub, studsub), stu) <- subTableQuery.filter(_.id === subjectId).join(studsubTableQuery).on(_.id === _.subid).
        join(studTableQuery).on(_._2.studid === _.id)
    } yield (sub.name, stu.name)

    db.run { retrieveStudents.result }
  }



  def getAllStudentSubject():Future[List[StudentSubjectData]]= {
    db.run {  studsubTableQuery.to[List].result
    }





  }

}



